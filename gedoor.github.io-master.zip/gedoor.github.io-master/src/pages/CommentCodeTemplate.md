
import Giscus from '@giscus/react';


## 讨论

<Giscus
  id="comments"
  repo="gedoor/gedoor.github.io"
  repoId="MDEwOlJlcG9zaXRvcnkxNjExMjczMjM"
  category="General"
  categoryId="DIC_kwDOCZqbm84CQvbE"
  mapping="title"
  term="Comments"
  reactionsEnabled="1"
  emitMetadata="0"
  inputPosition="top"
  theme="preferred_color_scheme"
  lang="zh-CN"
/>