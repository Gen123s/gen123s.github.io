---
slug: book-source-2022-7
title: 七月书源更新
authors: [heziyouyi]
tags: [书源,订阅]
---
import Giscus from '@giscus/react';


:::tip 提示
建议删除旧书源后再导入。
:::

<!-- truncate -->

## namofree

1. 修复失效书源，完善已有书源正文广告过滤规则；
2. 起点排行榜、纵横排行榜、追书排行榜仅适用于找书，阅读时建议换源；
3. 本书源适用于3.0版，2.0版阅读app应该大部分都能用，但不保证全部适用；
4. 友情提醒：订阅/导入地址有变更，有订阅的书友请自行替换；
5. 每次导入之前建议把之前的Namo分组删除全新导入！

**[点击此处导入](legado://import/bookSource?src=https://namofree.coding.net/p/yuedu/d/legado/git/raw/master/legadoNamo.json)**

```
https://namofree.coding.net/p/yuedu/d/legado/git/raw/master/legadoNamo.json
```

## 一程

### 书源

1. 更新28个书源
2. 新增22个书源
3. 删除46个书源
4. 建议删除旧书源再导入

**[点击此处导入](legado://import/bookSource?src=https://e-c.coding.net/p/yicheng/d/YD/git/raw/master/sy.json)**

```
https://e-c.coding.net/p/yicheng/d/YD/git/raw/master/sy.json
```

### 订阅

1. 更新2个网站
2. 新增13个网站
3. 删除9个网站

**[点击此处导入](legado://import/rssSource?src=https://e-c.coding.net/p/yicheng/d/YD/git/raw/master/dy.json)**

```
https://e-c.coding.net/p/yicheng/d/YD/git/raw/master/dy.json
```

发布地址：https://gitee.com/i-c/yd/blob/sy/README.md

## 讨论

<Giscus
  id="comments"
  repo="gedoor/gedoor.github.io"
  repoId="MDEwOlJlcG9zaXRvcnkxNjExMjczMjM"
  category="General"
  categoryId="DIC_kwDOCZqbm84CQvbE"
  mapping="title"
  term="Comments"
  reactionsEnabled="1"
  emitMetadata="0"
  inputPosition="top"
  theme="preferred_color_scheme"
  lang="zh-CN"
/>
