import Giscus from '@giscus/react';

# 完本小说推荐

## 2022

- [第七十三期](/endbook/73)

## 讨论

<Giscus
  id="comments"
  repo="gedoor/gedoor.github.io"
  repoId="MDEwOlJlcG9zaXRvcnkxNjExMjczMjM"
  category="General"
  categoryId="DIC_kwDOCZqbm84CQvbE"
  mapping="title"
  term="Comments"
  reactionsEnabled="1"
  emitMetadata="0"
  inputPosition="top"
  theme="preferred_color_scheme"
  lang="zh-CN"
/>