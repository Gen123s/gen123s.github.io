---
slug: welcome
title: 欢迎
authors: heziyouyi
tags: [hello, docusaurus]
---
import Giscus from '@giscus/react';

欢迎来到 开源阅读 博客

我们欢迎您来发布您的博客文章！

网站博客文件在：https://github.com/gedoor/gedoor.github.io/tree/master/blog

<!-- truncate -->

您只需将 Markdown 文件（或文件夹）添加到 `blog` 目录。

博客作者信息可以到 `authors.yml` 添加。

可以从文件名中提取博客文章日期，例如：

- `2020-04-28-welcome.md`
- `2020-04-28-welcome/index.md`

博客文章文件夹可以方便地放置博客文章图片：

![Docusaurus Plushie](./docusaurus-plushie-banner.jpeg)
- `![Docusaurus Plushie](./docusaurus-plushie-banner.jpeg)`

该博客也支持标签。

```
---
slug: welcome //网址的最后一部分（请使用英文）
title: 欢迎 //标题
authors: heziyouyi //作者（作者信息在 authors.yml 修改或添加）
tags: [hello, docusaurus] //标签
---
```

## 讨论

<Giscus
  id="comments"
  repo="gedoor/gedoor.github.io"
  repoId="MDEwOlJlcG9zaXRvcnkxNjExMjczMjM"
  category="General"
  categoryId="DIC_kwDOCZqbm84CQvbE"
  mapping="title"
  term="Comments"
  reactionsEnabled="1"
  emitMetadata="0"
  inputPosition="top"
  theme="preferred_color_scheme"
  lang="zh-CN"
/>